This is the code for the relay server for RPA and the MVP for the remote control feature developed during the summer of 2025.
Have fun interacting! Please try to keep any new additions modular.

Important Notes:
- Consider changing the redirect URI's port to 5005 instead of 8080 (workaround for anti-viruses blocking 8080)
- Double-check, (triple check if needed) to check if the django admin config is as expected. Can save you hours of debugging.