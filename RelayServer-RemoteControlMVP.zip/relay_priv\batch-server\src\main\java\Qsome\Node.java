// File: Qsome/Node.java
package Qsome;

// Standard Java I/O and utility imports
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.Stack;
import java.util.UUID;
import java.time.Duration;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.logging.Logger;
import java.nio.charset.StandardCharsets;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;

// HTTP Client imports
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

// JSON library imports (REQUIRED EXTERNAL DEPENDENCY)
import org.json.JSONObject;
import org.json.JSONArray; // Added for Actions.touch method

// AWT and JCodec imports (REQUIRED EXTERNAL DEPENDENCIES for JCodec, AWT is standard Java)
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.awt.image.DataBufferByte; // For QSSequenceEncoder
import javax.imageio.ImageIO; // For image processing

// JCodec specific imports
import org.jcodec.api.awt.AWTSequenceEncoder;
import org.jcodec.common.io.NIOUtils;
import org.jcodec.common.io.SeekableByteChannel;
import org.jcodec.common.model.Picture;
import org.jcodec.common.model.Rational;
import static org.jcodec.common.model.ColorSpace.RGB;


/**
 * Represents an RPA Orchestrator Node that communicates with the Django Relay Server.
 * Handles sending commands and retrieving responses, including file transfers.
 */
public class Node {
    private static final Logger logger = Logger.getLogger(Node.class.getName());

    private String orchestratorNodeId;
    private JSONObject nodeAttributes;
    private String relayServerBaseUrl;
    private String batchId;
    private String accessToken;
    private HttpClient httpClient;

    private Actions action;
    private Screen screen;

    // Timeout for the entire command execution process (sending + polling)
    public static final int COMMAND_EXECUTION_TIMEOUT_SECONDS = 60;
    // Interval for polling the command status
    private static final long POLLING_INTERVAL_MS = 500; // Poll every 500ms

    public Node(String orchestratorNodeId, JSONObject nodeAttributes, String relayServerUrl, String batchId, String accessToken) {
        this.orchestratorNodeId = orchestratorNodeId;
        this.nodeAttributes = nodeAttributes;
        this.relayServerBaseUrl = relayServerUrl.endsWith("/") ? relayServerUrl : relayServerUrl + "/";
        this.httpClient = HttpClient.newBuilder()
                                  .version(HttpClient.Version.HTTP_1_1)
                                  .connectTimeout(Duration.ofSeconds(10))
                                  .build();
        this.action = new Actions(this);
        this.screen = new Screen(this, action);
        this.batchId = batchId; 
        this.accessToken = accessToken; 
    }

    // Optional: Keep a constructor for backward compatibility, defaulting batchId and accessToken
    public Node(String botName, JSONObject nodeAttrs, String relayServerUrl) {
        this(botName, nodeAttrs, relayServerUrl, "default_batch", null); // Default batch ID and no access token
    }

    // --- sendHttpRequest Method (Helper for general HTTP POST) ---
    private CompletableFuture<JSONObject> sendHttpRequest(String url, String jsonPayload) {
        HttpRequest.Builder builder = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Content-Type", "application/json")
                .timeout(Duration.ofSeconds(COMMAND_EXECUTION_TIMEOUT_SECONDS)); // Use max timeout for HTTP request
        
        if (this.accessToken != null && !this.accessToken.isEmpty()) {
            builder.header("Authorization", "Bearer " + this.accessToken);
            System.out.println("Java: Including Authorization header for request to: " + url);
        }

        HttpRequest request = builder.POST(HttpRequest.BodyPublishers.ofString(jsonPayload))
                                     .build();
        System.out.println("Java: Sending HTTP POST to: " + url + " with payload: " + jsonPayload.substring(0, Math.min(jsonPayload.length(), 200)) + "..."); // Log truncated payload
        
        return httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                .thenApply(response -> {
                    System.out.println("Java: Received HTTP response status: " + response.statusCode());
                    System.out.println("Java: Received HTTP response body: " + response.body().substring(0, Math.min(response.body().length(), 200)) + "..."); // Log truncated body
                    if (response.statusCode() >= 200 && response.statusCode() < 300) { // Check for 2xx success codes
                        return new JSONObject(response.body());
                    } else {
                        throw new RuntimeException("Server returned non-2xx status: " + response.statusCode() + " Body: " + response.body());
                    }
                })
                .exceptionally(e -> {
                    System.err.println("Java: Failed to send HTTP request (exception): " + e.getMessage());
                    throw new RuntimeException("HTTP request failed: " + e.getMessage(), e);
                });
    }

    // --- sendRPACommand Method (Blocking execution with polling) ---
    public JSONObject sendRPACommand(String targetNodeId, JSONObject commandPayload) throws InterruptedException, ExecutionException, TimeoutException {
        System.out.println("Java: Preparing to send RPA command to node: " + targetNodeId + " CommandType: " + commandPayload.optString("commandType", "N/A"));
        
        String orchestratorRequestId = UUID.randomUUID().toString(); 
        
        commandPayload.put("orchestratorRequestId", orchestratorRequestId); 
        commandPayload.put("requestId", orchestratorRequestId); // Ensure requestId is in payload for client
        commandPayload.put("botName", this.orchestratorNodeId); // Identify the orchestrator

        // If commandType is present, also set command_type for Django's internal handling
        if (commandPayload.has("commandType")) {
            commandPayload.put("command_type", commandPayload.get("commandType"));
        }

        // 1. Send the command to the Relay Server (HTTP POST)
        // URL format: <httpApiBaseUrl><batch_id>/node/<node_id>/request/<request_id>/
        String sendCommandUrl = relayServerBaseUrl + this.batchId + "/node/" + targetNodeId + "/request/" + orchestratorRequestId + "/"; 

        JSONObject initialRelayResponse;
        try {
            initialRelayResponse = sendHttpRequest(sendCommandUrl, commandPayload.toString())
                                     .get(COMMAND_EXECUTION_TIMEOUT_SECONDS, TimeUnit.SECONDS); // Wait for initial relay acknowledgement
        } catch (Exception e) {
            System.err.println("Java: Failed to get initial Relay Server acknowledgement for command " + orchestratorRequestId + ": " + e.getMessage());
            throw e; // Re-throw to indicate failure
        }
        
        String relayStatus = initialRelayResponse.optString("status");
        String relayMessage = initialRelayResponse.optString("message");
        String requestIdFromRelay = initialRelayResponse.optString("request_id", orchestratorRequestId); // Use relay's ID if provided

        // Allow 'command_sent' or 'command_queued' as success for initial relay acknowledgement
        if (!"command_sent".equals(relayStatus) && !"command_queued".equals(relayStatus)) { 
            System.err.println("Java: Relay Server did not acknowledge command as 'command_sent' or 'command_queued'. Status: " + relayStatus + ", Message: " + relayMessage);
            throw new RuntimeException("Relay Server rejected command: " + relayMessage);
        }
        System.out.println("Java: Command " + requestIdFromRelay + " acknowledged by Relay. Status: " + relayStatus + ".");

        // 2. Poll the Relay Server for the command's final status using the ResponseView endpoint
        System.out.println("Java: Polling Relay Server for final status of command: " + requestIdFromRelay);
        long startTime = System.currentTimeMillis();
        
        while (System.currentTimeMillis() - startTime < COMMAND_EXECUTION_TIMEOUT_SECONDS * 1000) {
            try {
                // Poll the ResponseView endpoint directly for the final status
                // URL format: <relayServerBaseUrl><batch_id>/node/<node_id>/response/<request_id>/
                String pollResponseUrl = relayServerBaseUrl + this.batchId + "/node/" + targetNodeId + "/response/" + orchestratorRequestId + "/"; 
                
                HttpRequest.Builder builder = HttpRequest.newBuilder()
                    .uri(URI.create(pollResponseUrl))
                    .timeout(Duration.ofSeconds(10)) // Shorter timeout for individual poll requests
                    .GET();

                if (this.accessToken != null && !this.accessToken.isEmpty()) {
                    builder.header("Authorization", "Bearer " + this.accessToken);
                }
                HttpRequest request = builder.build();

                HttpResponse<String> response = httpClient.sendAsync(request, HttpResponse.BodyHandlers.ofString())
                                                        .get(POLLING_INTERVAL_MS, TimeUnit.MILLISECONDS);
                
                JSONObject polledResponse = new JSONObject(response.body());
                
                String topLevelStatus = polledResponse.optString("status");
                System.out.println("Java: Polling... Current status for " + requestIdFromRelay + ": " + topLevelStatus);

                // Check for final statuses
                if ("success".equalsIgnoreCase(topLevelStatus) ||
                    "error".equalsIgnoreCase(topLevelStatus) ||
                    "failed".equalsIgnoreCase(topLevelStatus) ||
                    "file_uploaded".equalsIgnoreCase(topLevelStatus)) { // Check for file_uploaded status
                    System.out.println("Java: Final status received for command " + requestIdFromRelay + ": " + topLevelStatus);
                    return polledResponse; // Return the full response from ResponseView
                }
                // If status is "pending" or any other non-final status, continue polling
            } catch (TimeoutException e) {
                // Polling timeout means the HTTP request for status itself timed out, which is okay if it's just one poll.
                System.out.println("Java: Polling request timed out, retrying...");
            } catch (Exception e) {
                System.err.println("Java: Error during polling for command " + requestIdFromRelay + ": " + e.getMessage());
                throw e; 
            }
            Thread.sleep(POLLING_INTERVAL_MS); // Wait before polling again
        }
        
        throw new TimeoutException("Command " + orchestratorRequestId + " timed out after " + COMMAND_EXECUTION_TIMEOUT_SECONDS + " seconds.");
    }

    /**
     * Checks if the response from the Relay Server indicates a successful RPA command execution.
     *
     * @param response The JSONObject response from the Relay Server.
     * @return true if the command was successful, false otherwise.
     */
    public boolean isRPACommandSuccessful(JSONObject polledResponse) {
        if (polledResponse == null) {
            return false;
        }
        // Check for top-level status first (e.g., from ResponseView for file uploads)
        String topLevelStatus = polledResponse.optString("status");
        if ("success".equalsIgnoreCase(topLevelStatus) || "file_uploaded".equalsIgnoreCase(topLevelStatus)) {
            return true;
        }

        // Then check for nested command_status (e.g., from /commands/status/) - this path is now removed from Django
        // but keeping the check for robustness if you have other status types.
        // However, for the current Django setup, all final responses come via ResponseView.
        if (polledResponse.has("response")) { // Check the 'response' object
            JSONObject innerResponse = polledResponse.optJSONObject("response");
            if (innerResponse != null) {
                String innerStatus = innerResponse.optString("status");
                if ("success".equalsIgnoreCase(innerStatus) || "file_uploaded".equalsIgnoreCase(innerStatus)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Extracts the actual RPA node's nested response payload
     * from the Django Relay Server's polled HTTP response.
     * This now also handles direct file upload details.
     * @param polledResponse The JSONObject received from polling /api/commands/status/ or /response/.
     * @return The nested 'responsePayload' JSONObject, the 'file_details' JSONObject, or an empty JSONObject if not found.
     */
    public JSONObject getRPACommandResponsePayload(JSONObject polledResponse) {
        if (polledResponse == null) {
            return new JSONObject();
        }
        
        // Priority 1: Check for 'response' object and then its 'responsePayload'
        if (polledResponse.has("response")) {
            JSONObject innerResponse = polledResponse.optJSONObject("response");
            if (innerResponse != null) {
                // If it has 'responsePayload', that's the primary content
                if (innerResponse.has("responsePayload")) {
                    return innerResponse.optJSONObject("responsePayload");
                }
                // If it has 'file_details' directly under 'response' (e.g., for file_uploaded status)
                if (innerResponse.has("file_details")) {
                    return innerResponse.optJSONObject("file_details");
                }
                // If 'response' itself is the payload (e.g., simple string/boolean response)
                // This is a fallback if no specific payload or file_details key is present.
                // Ensure it's not the full command structure itself.
                if (!innerResponse.has("status") && !innerResponse.has("requestId") && !innerResponse.has("error")) {
                     return innerResponse;
                }
            }
        }

        // Priority 2: Check for 'file_details' at the top level of the polled response
        // This might happen if Django's ResponseView directly returns file details at top level
        if (polledResponse.has("file_details")) {
            return polledResponse.optJSONObject("file_details");
        }
        
        // Fallback: If nothing specific is found, return the top-level response as payload
        // This is less ideal but ensures something is always returned.
        return polledResponse; 
    }

    /**
     * Sends a file from the Orchestrator to the RPA Client via a 'receive_file' command.
     *
     * @param targetRpaNodeId The ID of the target RPA Node.
     * @param sourceFile The local File object to send.
     * @param rpaClientDestinationFileName The filename for the file on the RPA client.
     * @return The JSONObject response from the Relay Server.
     * @throws IOException if the file cannot be read.
     * @throws Exception if the command sending or polling fails.
     */
    public JSONObject sendFileToRPAClient(String targetRpaNodeId, File sourceFile, String rpaClientDestinationFileName)
            throws InterruptedException, ExecutionException, TimeoutException, IOException {
        
        if (!sourceFile.exists() || !sourceFile.isFile()) {
            System.err.println("Java: sendFileToRPAClient failed: Source file does not exist or is not a file: " + sourceFile.getAbsolutePath());
            throw new IllegalArgumentException("Source file not found or not a file: " + sourceFile.getAbsolutePath());
        }

        // Read file content
        byte[] fileBytes = Files.readAllBytes(sourceFile.toPath());
        String base64FileContent = Base64.getEncoder().encodeToString(fileBytes);

        // Construct the 'receive_file' command payload for the RPA client
        JSONObject params = new JSONObject();
        params.put("filename", rpaClientDestinationFileName); // Target filename on RPA client
        params.put("file_content_base64", base64FileContent); // Base64 content (matches Python's expectation)

        JSONObject commandPayload = new JSONObject();
        commandPayload.put("commandType", "receive_file"); // Matches Python's SystemCommands.receive_file
        commandPayload.put("params", params);

        System.out.println("Java: Sending file '" + sourceFile.getName() + "' as command 'receive_file' to RPA node: " + targetRpaNodeId);

        // Send the command via the standard RPA command mechanism
        JSONObject finalRPAStatusResponse = sendRPACommand(targetRpaNodeId, commandPayload); 
        
        if (isRPACommandSuccessful(finalRPAStatusResponse)) {
            System.out.println("Java: sendFileToRPAClient command completed. File '" + sourceFile.getName() + "' sent to node '" + targetRpaNodeId + "' successfully.");
        } else {
            System.err.println("Java: sendFileToRPAClient command failed. Final server response: " + finalRPAStatusResponse.toString());
        }
        return finalRPAStatusResponse;
    }


    /**
     * Static method to receive a file (base64 content) from a JSONObject payload
     * and save it to a local directory.
     *
     * @param fileTransferPayload A JSONObject containing "filename" and "file_content_base64".
     * @param destinationDirectory The local directory to save the file.
     * @return The Path to the saved file.
     * @throws IOException if the file cannot be saved.
     */
    public static Path receiveFileAndSave(JSONObject fileTransferPayload, String destinationDirectory) throws IOException, IllegalArgumentException {
        String fileName = fileTransferPayload.optString("filename"); 
        String fileContentBase64 = fileTransferPayload.optString("file_content_base64"); 
        String requestId = fileTransferPayload.optString("request_id", fileTransferPayload.optString("requestId", "unknown")); // Handle both keys

        if (fileName.isEmpty() || fileContentBase64.isEmpty()) {
            throw new IllegalArgumentException("File transfer payload missing 'filename' or 'file_content_base64' for requestId: " + requestId);
        }

        System.out.println("Java: Batch Server receiving file for requestId: " + requestId + ", fileName: " + fileName);

        byte[] decodedBytes = Base64.getDecoder().decode(fileContentBase64);
        Path targetPath = Paths.get(destinationDirectory, fileName);

        Files.createDirectories(targetPath.getParent());

        Files.write(targetPath, decodedBytes);
        System.out.println("Java: Batch Server successfully saved received file: " + targetPath.toAbsolutePath());
        return targetPath;
    }


    /**
     * Public Static Helper Method: decodeBase64Image (Moved and made static)
     * Decodes a Base64 string into a BufferedImage.
     * @param base64Image The Base64 encoded image string.
     * @return A BufferedImage decoded from the string.
     * @throws IOException if an error occurs during image decoding.
     */
    public static BufferedImage decodeBase64Image(String base64Image) throws IOException {
        byte[] imageBytes = Base64.getDecoder().decode(base64Image);
        try (ByteArrayInputStream bais = new ByteArrayInputStream(imageBytes)) {
            return ImageIO.read(bais);
        }
    }

    /**
     * Public Static Helper Method: imageToBytes (Moved and made static)
     * Converts a BufferedImage to a byte array in a specified format.
     * @param image The BufferedImage to convert.
     * @param format The image format (e.g., "png", "jpeg").
     * @return A byte array representing the image.
     * @throws IOException if an error occurs during image encoding.
     */
    public static byte[] imageToBytes(BufferedImage image, String format) throws IOException {
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
            ImageIO.write(image, format, baos);
            return baos.toByteArray();
        }
    }


    // --- Accessor Methods for Actions and Screen ---
    public Actions action() {
        return this.action;
    }

    public Screen screen() {
        return this.screen;
    }

    public String getBotName() {
        return this.orchestratorNodeId; // Changed from botName to orchestratorNodeId for consistency
    }

    public void disconnect() {
        System.out.println("Java: Disconnecting Node resources.");
        if (action != null) {
            action.close();
        }
        if (screen != null) {
            screen.close();
        }
        System.out.println("Node disconnected.");
    }
}


// --- Actions.java (Adjusted to use new sendRPACommand and handle potential return data) ---
class Actions {
    private final Node node;
    Stack<Integer> keysDown = new Stack<Integer>();

    private static final Map<Character, Integer> SPLCHARS = new HashMap<Character, Integer>();
    static {
        SPLCHARS.put('-', KeyEvent.VK_MINUS);
        SPLCHARS.put('=', KeyEvent.VK_EQUALS);
        SPLCHARS.put('[', KeyEvent.VK_OPEN_BRACKET);
        SPLCHARS.put(']', KeyEvent.VK_CLOSE_BRACKET);
        SPLCHARS.put('\\', KeyEvent.VK_BACK_SLASH);
        SPLCHARS.put(';', KeyEvent.VK_SEMICOLON); 
        SPLCHARS.put('\'', KeyEvent.VK_QUOTE);
        SPLCHARS.put(',', KeyEvent.VK_COMMA);
        SPLCHARS.put('.', KeyEvent.VK_PERIOD);
        SPLCHARS.put('/', KeyEvent.VK_SLASH);
    }
    private static final Map<Character, Integer> SPLSHIFTCHARS = new HashMap<Character, Integer>();
    static {
        SPLSHIFTCHARS.put('!', KeyEvent.VK_1);
        SPLSHIFTCHARS.put('@', KeyEvent.VK_2);
        SPLSHIFTCHARS.put('#', KeyEvent.VK_3);
        SPLSHIFTCHARS.put('$', KeyEvent.VK_4);
        SPLSHIFTCHARS.put('%', KeyEvent.VK_5);
        SPLSHIFTCHARS.put('^', KeyEvent.VK_6);
        SPLSHIFTCHARS.put('&', KeyEvent.VK_7);
        SPLSHIFTCHARS.put('*', KeyEvent.VK_8);
        SPLSHIFTCHARS.put('(', KeyEvent.VK_9);
        SPLSHIFTCHARS.put(')', KeyEvent.VK_0);
        SPLSHIFTCHARS.put('_', KeyEvent.VK_MINUS);
        SPLSHIFTCHARS.put('+', KeyEvent.VK_EQUALS);
        SPLSHIFTCHARS.put('{', KeyEvent.VK_OPEN_BRACKET);
        SPLSHIFTCHARS.put('}', KeyEvent.VK_CLOSE_BRACKET);
        SPLSHIFTCHARS.put('|', KeyEvent.VK_BACK_SLASH);
        SPLSHIFTCHARS.put(':', KeyEvent.VK_COLON); 
        SPLSHIFTCHARS.put('\"', KeyEvent.VK_QUOTE);
        SPLSHIFTCHARS.put('<', KeyEvent.VK_COMMA);
        SPLSHIFTCHARS.put('>', KeyEvent.VK_PERIOD);
        SPLSHIFTCHARS.put('?', KeyEvent.VK_SLASH);
    }

    public Actions(Node n) {
        this.node = n;
    }

    public void close() {
        System.out.println("Actions class resources closed.");
    }

    public void mouseClick(int x, int y, int button) {
        JSONObject payload = new JSONObject();
        payload.put("commandType", "mouse_click");
        JSONObject params = new JSONObject();
        params.put("x", x);
        params.put("y", y);
        params.put("button", button);
        payload.put("params", params);

        try {
            JSONObject finalRPAStatusResponse = node.sendRPACommand(node.getBotName(), payload);
            if (node.isRPACommandSuccessful(finalRPAStatusResponse)) {
                System.out.println("Java: mouseClick command completed. Final server response: " + finalRPAStatusResponse.toString());
            } else {
                System.err.println("Java: mouseClick command failed. Final server response: " + finalRPAStatusResponse.toString());
            }
        } catch (TimeoutException e) {
            System.err.println("mouseClick command timed out: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("Error during mouseClick: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void mouseDoubleClick(int x, int y, int button) {
        JSONObject payload = new JSONObject();
        payload.put("commandType", "mouse_double_click");
        JSONObject params = new JSONObject();
        params.put("x", x);
        params.put("y", y);
        params.put("button", button);
        payload.put("params", params);

        try {
            JSONObject finalRPAStatusResponse = node.sendRPACommand(node.getBotName(), payload);
            if (node.isRPACommandSuccessful(finalRPAStatusResponse)) {
                System.out.println("Java: mouseDoubleClick command completed. Final server response: " + finalRPAStatusResponse.toString());
            } else {
                System.err.println("Java: mouseDoubleClick command failed. Final server response: " + finalRPAStatusResponse.toString());
            }
        } catch (TimeoutException e) {
            System.err.println("mouseDoubleClick command timed out: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("Error during mouseDoubleClick: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void keyEnter(int keyCode) {
        JSONObject payload = new JSONObject();
        payload.put("commandType", "key_press"); // Assuming key_press handles generic key codes
        JSONObject params = new JSONObject();
        params.put("key", KeyEvent.getKeyText(keyCode).toLowerCase()); // Convert keyCode to text for pyautogui
        payload.put("params", params);

        try {
            JSONObject finalRPAStatusResponse = node.sendRPACommand(node.getBotName(), payload);
            if (node.isRPACommandSuccessful(finalRPAStatusResponse)) {
                System.out.println("Java: keyEnter command completed. Final server response: " + finalRPAStatusResponse.toString());
            } else {
                System.err.println("Java: keyEnter command failed. Final server response: " + finalRPAStatusResponse.toString());
            }
        } catch (TimeoutException e) {
            System.err.println("keyEnter command timed out: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("Error during keyEnter: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void keyEnter(char letter) {
        if (Character.isLetterOrDigit(letter)
                || SPLCHARS.containsKey(letter)
                || SPLSHIFTCHARS.containsKey(letter)) {
            typeText(""+letter);
        }
    }

    public void keyDown(int keyCode) {
        JSONObject payload = new JSONObject();
        payload.put("commandType", "key_down"); // Needs implementation in Python `input.py`
        JSONObject params = new JSONObject();
        params.put("key", KeyEvent.getKeyText(keyCode).toLowerCase());
        payload.put("params", params);

        try {
            JSONObject finalRPAStatusResponse = node.sendRPACommand(node.getBotName(), payload);
            if (node.isRPACommandSuccessful(finalRPAStatusResponse)) {
                keysDown.add(keyCode); // Keep track locally if successful on RPA node
                System.out.println("Java: keyDown command completed. Final server response: " + finalRPAStatusResponse.toString());
            } else {
                System.err.println("Java: keyDown command failed. Final server response: " + finalRPAStatusResponse.toString());
            }
        } catch (TimeoutException e) {
            System.err.println("keyDown command timed out: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("Error during keyDown: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void keyUp() {
        if (keysDown.isEmpty()) {
            System.out.println("No keys are currently held down to release.");
            return;
        }
        int keyCode = keysDown.pop();
        JSONObject payload = new JSONObject();
        payload.put("commandType", "key_up"); // Needs implementation in Python `input.py`
        JSONObject params = new JSONObject();
        params.put("key", KeyEvent.getKeyText(keyCode).toLowerCase());
        payload.put("params", params);

        try {
            JSONObject finalRPAStatusResponse = node.sendRPACommand(node.getBotName(), payload);
            if (node.isRPACommandSuccessful(finalRPAStatusResponse)) {
                System.out.println("Java: keyUp command completed. Final server response: " + finalRPAStatusResponse.toString());
            } else {
                System.err.println("Java: keyUp command failed. Final server response: " + finalRPAStatusResponse.toString());
            }
        } catch (TimeoutException e) {
            System.err.println("keyUp command timed out: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("Error during keyUp: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void releaseDownKeys() {
        while (!keysDown.isEmpty()) {
            keyUp(); 
        }
    }

    public void typeText(String text) {
        JSONObject payload = new JSONObject();
        payload.put("commandType", "type_text");
        JSONObject params = new JSONObject();
        params.put("text", text);
        payload.put("params", params);

        try {
            JSONObject finalRPAStatusResponse = node.sendRPACommand(node.getBotName(), payload);
            if (node.isRPACommandSuccessful(finalRPAStatusResponse)) {
                System.out.println("Java: typeText command completed. Final server response: " + finalRPAStatusResponse.toString());
            } else {
                System.err.println("Java: typeText command failed. Final server response: " + finalRPAStatusResponse.toString());
            }
        } catch (TimeoutException e) {
            System.err.println("typeText command timed out: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("Error during typeText: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void touch(String[] stepList) {
        JSONObject payload = new JSONObject();
        payload.put("commandType", "touch_sequence"); // Needs implementation in Python `input.py`
        JSONObject params = new JSONObject();
        params.put("steps", new JSONArray(stepList)); // JSONArray is used here
        payload.put("params", params);

        try {
            JSONObject finalRPAStatusResponse = node.sendRPACommand(node.getBotName(), payload);
            if (node.isRPACommandSuccessful(finalRPAStatusResponse)) {
                System.out.println("Java: touch command completed. Final server response: " + finalRPAStatusResponse.toString());
            } else {
                System.err.println("Java: touch command failed. Final server response: " + finalRPAStatusResponse.toString());
            }
        } catch (TimeoutException e) {
            System.err.println("touch sequence command timed out: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("Error during touch sequence: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public String copyClipboard() {
        JSONObject payload = new JSONObject();
        payload.put("commandType", "copy_clipboard"); // Needs implementation in Python `input.py`

        try {
            JSONObject finalRPAStatusResponse = node.sendRPACommand(node.getBotName(), payload);
            if (node.isRPACommandSuccessful(finalRPAStatusResponse)) {
                System.out.println("Java: copyClipboard command completed. Final server response: " + finalRPAStatusResponse.toString());
                JSONObject rpaResponse = node.getRPACommandResponsePayload(finalRPAStatusResponse);
                return rpaResponse.optString("clipboardContent", null);
            } else {
                System.err.println("Java: copyClipboard command failed. Final server response: " + finalRPAStatusResponse.toString());
                return null;
            }
        } catch (TimeoutException e) {
            System.err.println("copyClipboard command timed out: " + e.getMessage());
            e.printStackTrace();
            return null;
        } catch (Exception e) {
            System.err.println("Error during copyClipboard: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    public String runCmd(String cmd) {
        JSONObject payload = new JSONObject();
        payload.put("commandType", "run_shell_command"); // Mapped to run_shell_command in Python
        JSONObject params = new JSONObject();
        params.put("command", cmd); // Use "command" as the parameter key
        payload.put("params", params);

        try {
            JSONObject finalRPAStatusResponse = node.sendRPACommand(node.getBotName(), payload);
            if (node.isRPACommandSuccessful(finalRPAStatusResponse)) {
                System.out.println("Java: runCmd command completed. Final server response: " + finalRPAStatusResponse.toString());
                JSONObject rpaResponse = node.getRPACommandResponsePayload(finalRPAStatusResponse);
                // Assuming RPA client returns 'stdout' for successful shell commands
                return rpaResponse.optString("stdout", null); 
            } else {
                System.err.println("Java: runCmd command failed. Final server response: " + finalRPAStatusResponse.toString());
                // For failures, you might want to return stderr or an error message
                JSONObject rpaResponse = node.getRPACommandResponsePayload(finalRPAStatusResponse);
                return "ERROR: " + rpaResponse.optString("message", "Unknown error") + 
                       (rpaResponse.has("stderr") ? "\nStderr: " + rpaResponse.optString("stderr") : "");
            }
        } catch (TimeoutException e) {
            System.err.println("runCmd command timed out: " + e.getMessage());
            e.printStackTrace();
            return null;
        } catch (Exception e) {
            System.err.println("Error during runCmd: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }
}


// --- Screen.java (Adjusted to use new sendRPACommand and handle potential return data) ---
class Screen {
    private final Node node;
    private final Actions action;

    public Screen(Node n, Actions a) {
        this.node = n;
        this.action = a;
    }

    public void close() {
        System.out.println("Screen class resources closed.");
    }

    public BufferedImage screenshot() {
        JSONObject payload = new JSONObject();
        payload.put("commandType", "screenshot");

        try {
            JSONObject finalRPAStatusResponse = node.sendRPACommand(node.getBotName(), payload);
            if (node.isRPACommandSuccessful(finalRPAStatusResponse)) {
                System.out.println("Java: screenshot command completed. Final server response: " + finalRPAStatusResponse.toString());
                
                if ("file_uploaded".equalsIgnoreCase(finalRPAStatusResponse.optString("status")) || 
                    (finalRPAStatusResponse.has("response") && "file_uploaded".equalsIgnoreCase(finalRPAStatusResponse.optJSONObject("response").optString("status")))) {
                    
                    JSONObject fileDetails = node.getRPACommandResponsePayload(finalRPAStatusResponse); 
                    String base64Image = fileDetails.optString("file_content_base64", null); 
                    
                    if (base64Image != null && !base64Image.isEmpty()) {
                        return Node.decodeBase64Image(base64Image); 
                    } else {
                        System.err.println("Java: screenshot command returned 'file_uploaded' status but missing base64 content in payload.");
                    }
                } else {
                    System.err.println("Java: screenshot command did not return expected 'file_uploaded' status. Response: " + finalRPAStatusResponse.toString());
                }
            } else {
                System.err.println("Java: screenshot command failed. Final server response: " + finalRPAStatusResponse.toString());
            }
            return null;
        } catch (TimeoutException e) {
            System.err.println("screenshot command timed out: " + e.getMessage());
            e.printStackTrace();
            return null;
        } catch (Exception e) {
            System.err.println("Error during screenshot: " + e.getMessage());
            e.printStackTrace();
            return null;
        }
    }

    public boolean findImage(BufferedImage image) {
        try {
            String base64Image = Base64.getEncoder().encodeToString(Node.imageToBytes(image, "png"));
            JSONObject payload = new JSONObject();
            payload.put("commandType", "find_image"); 
            JSONObject params = new JSONObject();
            params.put("image", base64Image);
            payload.put("params", params);

            JSONObject finalRPAStatusResponse = node.sendRPACommand(node.getBotName(), payload);
            if (node.isRPACommandSuccessful(finalRPAStatusResponse)) {
                System.out.println("Java: findImage command completed. Final server response: " + finalRPAStatusResponse.toString());
                JSONObject rpaResponse = node.getRPACommandResponsePayload(finalRPAStatusResponse);
                return rpaResponse.optBoolean("found", false);
            } else {
                System.err.println("Java: findImage command failed. Final server response: " + finalRPAStatusResponse.toString());
                return false;
            }
        } catch (TimeoutException e) {
            System.err.println("findImage command timed out: " + e.getMessage());
            e.printStackTrace();
            return false;
        } catch (InterruptedException e) { 
            Thread.currentThread().interrupt(); 
            System.err.println("findImage command interrupted: " + e.getMessage());
            e.printStackTrace();
            return false;
        } catch (ExecutionException e) { 
            System.err.println("findImage command execution error: " + e.getCause().getMessage());
            e.printStackTrace();
            return false;
        } catch (Exception e) { 
            System.err.println("Error during findImage: " + e.getMessage());
            e.printStackTrace();
            return false;
        }
    }

    public boolean findImageInRegion(BufferedImage image, int x, int y, int width, int height) {
        try {
            String base64Image = Base64.getEncoder().encodeToString(Node.imageToBytes(image, "png"));
            JSONObject payload = new JSONObject();
            payload.put("commandType", "find_image_in_region"); 
            JSONObject params = new JSONObject();
            params.put("image", base64Image);
            params.put("x", x);
            params.put("y", y);
            params.put("width", width);
            params.put("height", height);
            payload.put("params", params);

            JSONObject finalRPAStatusResponse = node.sendRPACommand(node.getBotName(), payload);
            if (node.isRPACommandSuccessful(finalRPAStatusResponse)) {
                System.out.println("Java: findImageInRegion command completed. Final server response: " + finalRPAStatusResponse.toString());
                JSONObject rpaResponse = node.getRPACommandResponsePayload(finalRPAStatusResponse);
                return rpaResponse.optBoolean("found", false);
            } else {
                System.err.println("Java: findImageInRegion command failed. Final server response: " + finalRPAStatusResponse.toString());
                return false;
            }
        } catch (TimeoutException e) {
            System.err.println("findImageInRegion command timed out: " + e.getMessage());
            e.printStackTrace();
            return false;
        } catch (Exception e) {
            System.err.println("Error during findImageInRegion: " + e.getMessage());
            e.printStackTrace();
        }
        return false; // Added return statement for all paths
    }

    public void clickImage(BufferedImage image) {
        JSONObject payload = new JSONObject();
        payload.put("commandType", "click_image"); 
        try {
            String base64Image = Base64.getEncoder().encodeToString(Node.imageToBytes(image, "png"));
            JSONObject params = new JSONObject();
            params.put("image", base64Image);
            payload.put("params", params);

            JSONObject finalRPAStatusResponse = node.sendRPACommand(node.getBotName(), payload);
            if (node.isRPACommandSuccessful(finalRPAStatusResponse)) {
                System.out.println("Java: clickImage command completed. Final server response: " + finalRPAStatusResponse.toString());
            } else {
                System.err.println("Java: clickImage command failed. Final server response: " + finalRPAStatusResponse.toString());
            }
        } catch (TimeoutException e) {
            System.err.println("clickImage command timed out: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("Error during clickImage: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void clickImageInRegion(BufferedImage image, int x, int y, int width, int height) {
        JSONObject payload = new JSONObject();
        payload.put("commandType", "click_image_in_region"); 
        try {
            String base64Image = Base64.getEncoder().encodeToString(Node.imageToBytes(image, "png"));
            JSONObject params = new JSONObject();
            params.put("image", base64Image);
            params.put("x", x);
            params.put("y", y);
            params.put("width", width);
            params.put("height", height);
            payload.put("params", params);

            JSONObject finalRPAStatusResponse = node.sendRPACommand(node.getBotName(), payload);
            if (node.isRPACommandSuccessful(finalRPAStatusResponse)) {
                System.out.println("Java: clickImageInRegion command completed. Final server response: " + finalRPAStatusResponse.toString());
            } else {
                System.err.println("Java: clickImageInRegion command failed. Final server response: " + finalRPAStatusResponse.toString());
            }
        } catch (TimeoutException e) {
            System.err.println("clickImageInRegion command timed out: " + e.getMessage());
            e.printStackTrace();
        } catch (Exception e) {
            System.err.println("Error during clickImageInRegion: " + e.getMessage());
            e.printStackTrace();
        }
    }
}


// --- QSSequenceEncoder.java (Re-integrated, assuming JCodec dependencies are available) ---
class QSSequenceEncoder extends AWTSequenceEncoder {

    public QSSequenceEncoder(SeekableByteChannel out, Rational fps) throws IOException {
        super(out, fps);
    }

    public static QSSequenceEncoder createSequenceEncoder(File out, int fps) throws IOException {
        return new QSSequenceEncoder(NIOUtils.writableChannel(out), Rational.R(fps, 1));
    }

    public void encodeImage(BufferedImage bi) throws IOException {
        encodeNativeFrame(fromBufferedImageRGB(bi));
    }

    private static Picture fromBufferedImageRGB(BufferedImage src) {
        Picture dst = Picture.create(src.getWidth(), src.getHeight(), RGB);
        fromBufferedImage(src, dst);
        return dst;
    }

    private static void fromBufferedImage(BufferedImage src, Picture dst) {
        byte[] dstData = dst.getPlaneData(0);
        byte[] srcData = ((DataBufferByte)src.getRaster().getDataBuffer()).getData();
        for (int i=0;i<(srcData.length/3);i++) {
            int j=i*3;
            dstData[j] = srcData[j];
            dstData[j+1] = srcData[j+1];
            dstData[j+2] = srcData[j+2];
        }
    }
}
